from modules.greet import greet

def main(a):
    print(a)
    np.__version__

if __name__ == '__main__':
    main();
    greet()